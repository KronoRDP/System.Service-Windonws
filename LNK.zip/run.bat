@echo off
cd /d "%~dp0"
rundll32.exe advpack.dll,LaunchINFSection "%~dp0x.inf",DefaultInstall